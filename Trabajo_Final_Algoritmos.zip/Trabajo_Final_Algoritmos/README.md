
# Project Title

Planeación ingeniería industrial 2024-2.

# Nombre del Proyecto

![Imagen Representativa del Proyecto]("C:\Users\Admin\OneDrive\Escritorio\logo_proyecto.png")

## Integrantes del Proyecto

- Gabriela Tejada Arias
- Keudith Manco Sencio
- Natalia Restrepo Calvo

## Programa Académico

Ingeniería Industrial

## Licencia

Este proyecto está registrado bajo la licencia MIT.